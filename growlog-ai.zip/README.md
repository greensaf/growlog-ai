
# Growlog.ai MVP

## Что реализовано:
- PWA, Whisper, ChatGPT JSON, Supabase, UploadThing
- Авторизация через Auth0
- Настоящие иконки в папке public