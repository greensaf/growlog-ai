growlogdb
Public Environment Variables Prefix - NEXT_PUBLIC_

git remote add origin https://github.com/greensaf/growlog-ai.git
git add .
git commit -m "Initial working MVP"
git branch -M main
git push -u origin main
