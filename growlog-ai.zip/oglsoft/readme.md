Внутри:
Файл	Назначение
GrowlogApp.tsx	Основной интерфейс приложения
pages/api/whisper-chatgpt.ts	Распознавание и анализ
pages/api/auth/[...auth0].ts	Маршруты входа/выхода Auth0
.env.example	Все переменные окружения
next.config.js	Включение PWA
public/manifest.json	Настройки PWA
public/*	🎨 Твои логотипы и иконки
README.md	Инструкция по запуск